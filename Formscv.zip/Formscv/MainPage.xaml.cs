﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xamarin.Forms;

namespace Formscv
{
    public partial class MainPage : ContentPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
        private void cbox_terminos_CheckedChanged(object sender, CheckedChangedEventArgs e)
        {

        }
        private void btn_registrar_Clicked(object sender, EventArgs e)
        {

        }
        private void sw_example_Toggled(object sender, ToggledEventArgs e)
        {

        }
        private void lbl_nombre_Completed(object sender, EventArgs e)
        {

        }
        private void lbl_nombre_Textchanged(object sender, TextChangedEventArgs e)
        {

        }
        private void lbl_correo_Completed(object sender, EventArgs e)
        {

        }
        private void lbl_password_Completed(object sender, EventArgs e)
        {

        }
        private void lbl_password2_Completed(object sender, EventArgs e)
        {

        }
    }
}
